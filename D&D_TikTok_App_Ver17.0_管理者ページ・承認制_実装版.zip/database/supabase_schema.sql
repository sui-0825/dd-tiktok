-- D&D❀TikTok Ver14.1 Supabase初期設定
create extension if not exists pgcrypto;

create table if not exists workspaces (
  id uuid primary key default gen_random_uuid(),
  name text not null default 'D&D❀TikTok',
  created_at timestamptz not null default now()
);
create table if not exists workspace_members (
  workspace_id uuid not null references workspaces(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  role text not null default 'member',
  created_at timestamptz not null default now(),
  primary key(workspace_id,user_id)
);
create table if not exists profiles (
  user_id uuid primary key references auth.users(id) on delete cascade,
  workspace_id uuid not null references workspaces(id) on delete cascade,
  display_name text not null,
  sort_order integer not null default 0,
  last_seen_at timestamptz,
  created_at timestamptz not null default now()
);
create table if not exists app_snapshots (
  workspace_id uuid primary key references workspaces(id) on delete cascade,
  revision bigint not null default 1,
  payload jsonb not null default '{}'::jsonb,
  updated_by uuid references auth.users(id),
  updated_at timestamptz not null default now()
);
create table if not exists import_jobs (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid not null references workspaces(id) on delete cascade,
  file_name text,
  status text not null default 'preview',
  summary jsonb not null default '{}'::jsonb,
  created_by uuid references auth.users(id),
  created_at timestamptz not null default now()
);

alter table workspaces enable row level security;
alter table workspace_members enable row level security;
alter table profiles enable row level security;
alter table app_snapshots enable row level security;
alter table import_jobs enable row level security;

-- 初期導入用: workspaceIdを知っているログイン済みユーザーが参加可能
create policy "workspace readable" on workspaces for select to authenticated using (true);
create policy "member self join" on workspace_members for insert to authenticated with check (user_id=auth.uid());
create policy "members readable" on workspace_members for select to authenticated using (true);
create policy "profile own write" on profiles for all to authenticated using (user_id=auth.uid()) with check (user_id=auth.uid());
create policy "profiles readable" on profiles for select to authenticated using (true);
create policy "snapshot readable" on app_snapshots for select to authenticated using (true);
create policy "snapshot insert" on app_snapshots for insert to authenticated with check (true);
create policy "snapshot update" on app_snapshots for update to authenticated using (true) with check (true);
create policy "imports own" on import_jobs for all to authenticated using (created_by=auth.uid()) with check (created_by=auth.uid());

-- 最初のworkspaceを1件作成し、表示されたidをbackend-config.jsへ貼り付けます。
insert into workspaces(name) values ('D&D❀TikTok') returning id;
